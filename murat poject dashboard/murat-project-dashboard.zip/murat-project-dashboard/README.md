# Murat Project Portfolio Dashboard

Interactive mobile-first portfolio map for Murat Project Engineer.

## Local preview
Open `public/index.html` in a browser.

## Cloudflare Workers deploy
```bash
npx wrangler deploy
```

The dashboard is a static Worker Assets site. The portfolio data is embedded in `public/index.html` for v1; the weekly ritual updates the snapshot and redeploys it.
